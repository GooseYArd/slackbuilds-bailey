#include "uploaddocumentdialog.h"

namespace Kobby
{

UploadDocumentDialog::UploadDocumentDialog(const QString &doc_name,
	QWidget *parent)
	: KDialog(parent)
{
}

}

