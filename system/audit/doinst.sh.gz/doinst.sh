#!/bin/sh

if [ ! -e var/log/audit ]; then
  mkdir -p var/log/audit
  chmod 755 var/log/audit
fi

if [ ! -e var/lock/subsys ]; then
  mkdir -p var/lock/subsys
  chmod 755 var/lock/subsys
fi


config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

# Keep same perms on rc.httpd.new:
if [ -e etc/rc.d/rc.auditd ]; then
  cp -a etc/rc.d/rc.auditd etc/rc.d/rc.auditd.new.incoming
  cat etc/rc.d/rc.auditd.new > etc/rc.d/rc.auditd.new.incoming
  mv etc/rc.d/rc.auditd.new.incoming etc/rc.d/rc.auditd.new
fi

config etc/rc.d/rc.auditd.new
config etc/rc.d/rc.auditd.conf.new
config etc/audit/audit.rules.new
config etc/audit/auditd.conf.new
config etc/audisp/audispd.conf.new
config etc/audisp/zos-remote.conf.new
config etc/audisp/plugins.d/af_unix.conf.new
config etc/audisp/plugins.d/au-remote.conf.new
config etc/audisp/plugins.d/audispd-zos-remote.conf.new
config etc/audisp/plugins.d/syslog.conf.new
config etc/audisp/audisp-remote.conf.new

( cd usr/lib64 ; rm -rf libauparse.so.0 )
( cd usr/lib64 ; ln -sf libauparse.so.0.0.0 libauparse.so.0 )
( cd usr/lib64 ; rm -rf libaudit.so )
( cd usr/lib64 ; ln -sf libaudit.so.1.0.0 libaudit.so )
( cd usr/lib64 ; rm -rf libaudit.so.1 )
( cd usr/lib64 ; ln -sf libaudit.so.1.0.0 libaudit.so.1 )
( cd usr/lib64 ; rm -rf libauparse.so )
( cd usr/lib64 ; ln -sf libauparse.so.0.0.0 libauparse.so )


